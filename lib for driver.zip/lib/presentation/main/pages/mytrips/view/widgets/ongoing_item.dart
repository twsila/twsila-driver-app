import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taxi_for_you/utils/ext/date_ext.dart';

import '../../../../../../app/app_prefs.dart';
import '../../../../../../app/di.dart';
import '../../../../../../domain/model/driver_model.dart';
import '../../../../../../domain/model/trip_details_model.dart';
import '../../../../../../utils/ext/enums.dart';
import '../../../../../../utils/resources/assets_manager.dart';
import '../../../../../../utils/resources/color_manager.dart';
import '../../../../../../utils/resources/constants_manager.dart';
import '../../../../../../utils/resources/font_manager.dart';
import '../../../../../../utils/resources/routes_manager.dart';
import '../../../../../../utils/resources/strings_manager.dart';
import '../../../../../../utils/resources/values_manager.dart';
import '../../../../../common/widgets/custom_card.dart';
import '../../../../../trip_execution/view/trip_execution_view.dart';
import '../../bloc/my_trips_bloc.dart';

class OngoingItemView extends StatefulWidget {
  TripDetailsModel trip;
  String currentTripModelId;
  String date;

  OngoingItemView(
      {required this.trip,
      required this.currentTripModelId,
      required this.date});

  @override
  State<OngoingItemView> createState() => _OngoingItemViewState();
}

class _OngoingItemViewState extends State<OngoingItemView> {
  String driverServiceType = "";
  final AppPreferences _appPreferences = instance<AppPreferences>();

  @override
  void initState() {
    driverServiceType = _appPreferences.getCachedDriver()!.captainType ==
            RegistrationConstants.captain
        ? (_appPreferences.getCachedDriver()! as Driver).serviceTypes!.first
        : "";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomCard(
      onClick: () {
        Navigator.pushNamed(context, Routes.tripExecution,
                arguments: TripExecutionArguments(widget.trip))
            .then((value) => BlocProvider.of<MyTripsBloc>(context)
                .add(GetTripsTripModuleId(widget.currentTripModelId)));
        // Navigator.pushNamed(context, Routes.tripDetails,
        //     arguments: TripDetailsArguments(tripModel: trip));
      },
      bodyWidget: Container(
        margin: EdgeInsets.all(AppMargin.m8),
        padding: EdgeInsets.only(
            top: AppPadding.p8,
            left: AppPadding.p8,
            right: AppPadding.p8,
            bottom: AppPadding.p2),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  color: ColorManager.primaryBlueBackgroundColor,
                  padding: EdgeInsets.all(AppPadding.p2),
                  child: Padding(
                    padding: const EdgeInsets.all(AppPadding.p4),
                    child: Row(
                      children: [
                        Image.asset(
                          widget.trip.tripDetails.date != null &&
                                  widget.trip.tripDetails.date != ""
                              ? ImageAssets.scheduledTripIc
                              : ImageAssets.asSoonAsPossibleTripIc,
                          width: AppSize.s14,
                        ),
                        SizedBox(
                          width: AppSize.s4,
                        ),
                        Text(
                          widget.date != null && widget.date != ""
                              ? AppStrings.scheduled.tr() +
                                  " : ${widget.date.getTimeStampFromDate()}"
                              : AppStrings.asSoonAsPossible.tr(),
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                  color: ColorManager.headersTextColor,
                                  fontSize: FontSize.s12,
                                  fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
                // SvgPicture.asset(ImageAssets.truckIc,),
                Image.asset(
                  getIconName(widget.trip.tripDetails.tripType!),
                  width: AppSize.s40,
                ),
              ],
            ),
            SizedBox(
              height: AppSize.s4,
            ),
            Text(
              getTitle(widget.trip.tripDetails.tripType!),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: ColorManager.headersTextColor,
                  fontSize: FontSize.s14,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: AppSize.s4,
            ),
            Text(
              "${widget.trip.tripDetails.pickupLocation.locationName} - ${widget.trip.tripDetails.destinationLocation.locationName}",
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: ColorManager.headersTextColor,
                  fontSize: FontSize.s14,
                  fontWeight: FontWeight.normal),
            ),
            Divider(
              color: ColorManager.dividerColor,
              thickness: 1,
            ),
            SizedBox(
              height: AppSize.s4,
            ),
            Text(
              tripStepperTitles(
                  widget.trip.tripDetails.tripStatus.toString(),
                  driverServiceType.isNotEmpty ? driverServiceType : "PERSONS",
                  _appPreferences.getCachedDriver()!.captainType.toString()),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: getTripStatusDisColor(
                      widget.trip.tripDetails.tripStatus.toString()),
                  fontSize: FontSize.s14,
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: AppSize.s4,
            ),
            Visibility(
              visible: tripStepperDisc(
                      widget.trip.tripDetails.tripStatus.toString(),
                      driverServiceType.isNotEmpty
                          ? driverServiceType
                          : "PERSONS",
                      _appPreferences.getCachedDriver()!.captainType.toString())
                  .isNotEmpty,
              child: Text(
                tripStepperDisc(
                    widget.trip.tripDetails.tripStatus.toString(),
                    driverServiceType.isNotEmpty
                        ? driverServiceType
                        : "PERSONS",
                    _appPreferences.getCachedDriver()!.captainType.toString()),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: ColorManager.titlesTextColor,
                    fontSize: FontSize.s12,
                    fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
